ZERO TO EMPIRE — CHARACTER GENERATION VALIDATION PACK

Manual visual-review contact sheets only. NOT runtime-ready atlases.
Check identity consistency, pose coherence, silhouette separation, profession readability, style consistency, malformed/duplicated subjects and background artifacts.
Approved selections still require extraction/normalization, technical QA, exact runtime mapping and Android CI.
